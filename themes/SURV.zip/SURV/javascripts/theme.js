var PurpleMine=PurpleMine||{};PurpleMine.HistoryTabs=function(){"use strict";var a,n={en:{all:"All",notes:"Notes",details:"Changes"},ro:{all:"Toate",notes:"Note",details:"Schimbări"},fr:{all:"Tout",notes:"Remarques",details:"Changements"},pl:{all:"Wszystko",notes:"Notatki",details:"Zmiany"},de:{all:"Alles",notes:"Kommentare",details:"Änderungen"},ja:{all:"すべて",notes:"注記",details:"変更"}};var r=function(){var e=$(this),t=e.attr("data-tab");a.$tabs.removeClass("selected"),e.addClass("selected"),a.$history.removeClass("hide-details").removeClass("hide-notes"),"notes"===t?a.$history.addClass("hide-details"):"details"===t&&a.$history.addClass("hide-notes")};return function(){if(a)return a;var e,t,i,s;(a=this).$tabsContainer=null,this.$tabs=null,this.$history=$("#history"),this.lang=document.documentElement.lang,void 0===n[this.lang]&&(this.lang="en"),this._=n[this.lang],0<this.$history.length&&0<$("#history > h3").length&&(e="",s="</a></li>",e=(e=(e=(e+='<div class="tabs"><ul>')+(t='<li><a href="javascript:;" class="')+"selected "+(i='history-tab" data-tab="')+'all">'+a._.all+s)+t+i+'notes">'+a._.notes+s)+t+i+'details">'+a._.details+s+"</ul></div>",a.$tabsContainer=$(e),$("#history > h3").after(a.$tabsContainer),a.$tabs=a.$tabsContainer.find(".history-tab"),a.$tabs.on("click",r),a.$history.find(".has-notes:first").addClass("first-of-notes"),a.$history.find(".has-details:first").addClass("first-of-details"))}}(),(PurpleMine=PurpleMine||{}).MenuCollapse=function(){"use strict";var s,t={en:{topMenuToggler:"Expand/collapse top menu"},ro:{topMenuToggler:"Deschide/închide meniul de sus"},fr:{topMenuToggler:"Développer/réduire le menu principal"},pl:{topMenuToggler:"Zwiń/rozwiń górne menu"},de:{topMenuToggler:"Ein-/Ausklappen Hauptmenu"},ja:{topMenuToggler:"トップメニューの展開/折りたたみ"}};function e(){if(s)return s;for(var e in(s=this).lang=document.documentElement.lang,void 0===t[this.lang]&&(this.lang="en"),this._=t[this.lang],this.menus={top:{$el:$("#top-menu")}},this.menus)this.menus.hasOwnProperty(e)&&0<this.menus[e].$el.length&&!function(e){if("none"===s.menus[e].$el.css("maxHeight"))return;s.menus[e].collapsed=!0,window.localStorage&&(s.menus[e].collapsed=null===localStorage.getItem(i(e)));(function(e){var t=e+"-menu-toggler",i=s._[e+"MenuToggler"],t='<a href="javascript:;" class="'+t+'" title="'+i+'"></a>';s.menus[e].$toggler=$(t),s.menus[e].$el.prepend(s.menus[e].$toggler),s.menus[e].$toggler.on("click",{menu:e},s.toggleMenu)})(e),!1===s.isCollapsed(e)&&s.expandMenu(e)}(e)}function i(e){return"PurpleMine:"+e+"MenuExpanded"}return e.prototype.toggleMenu=function(e){e=e.data.menu||"";s.isCollapsed(e)?s.expandMenu(e):s.collapseMenu(e)},e.prototype.isCollapsed=function(e){return this.menus[e].collapsed},e.prototype.expandMenu=function(e){this.menus[e].$el.addClass("expanded"),this.menus[e].$toggler.addClass("expanded"),this.menus[e].collapsed=!1,window.localStorage&&localStorage.setItem(i(e),"x")},e.prototype.collapseMenu=function(e){this.menus[e].$el.removeClass("expanded"),this.menus[e].$toggler.removeClass("expanded"),this.menus[e].collapsed=!0,window.localStorage&&localStorage.removeItem(i(e))},e}(),(PurpleMine=PurpleMine||{}).RevisionGraph=function(e,t,i){"use strict";var s,a,n,r,o,l,d,u=t,t=$.map(u,function(e){return e}),h=t.length-1,p=$("table.changesets tr.changeset"),g=(null!==revisionGraph?revisionGraph.clear():revisionGraph=new Raphael(e),revisionGraph.set()),c=p.first().find("td").first().position().left-$(e).position().left,m=$(e).position().top,e=c+20*(i+1),b=p.last().position().top+p.last().height()-m,f=(revisionGraph.setSize(e,b),["#e74c3c","#584492","#019851","#ed820c","#4183c4"]);if(f.length<=i){Raphael.getColor.reset();for(var v=0;v<=i;v++)f.push(Raphael.getColor(.9))}$.each(t,function(e,i){i.hasOwnProperty("space")||(i.space=0),n=p.eq(h-i.rdmid).position().top-m+17,a=10+c+20*i.space,revisionGraph.circle(a,n,3.5).attr({fill:f[i.space],stroke:"none"}).toFront(),$.each(i.parent_scmids,function(e,t){s=u[t],(s?(s.hasOwnProperty("space")||(s.space=0),o=p.eq(h-s.rdmid).position().top-m+17,r=10+c+20*s.space,s.space===i.space?revisionGraph.path(["M",a,n,"V",o]):revisionGraph.path(["M",a,n,"C",a,n,a,n+(o-n)/2,a+(r-a)/2,n+(o-n)/2,"C",a+(r-a)/2,n+(o-n)/2,r,o-(o-n)/2,r,o])):revisionGraph.path(["M",a,n,"V",b])).attr({stroke:f[i.space],"stroke-width":1.5}).toBack()}),(d=revisionGraph.circle(a,n,10)).attr({fill:"#000",opacity:0,cursor:"pointer",href:i.href}),null!==i.refs&&0<i.refs.length&&((l=document.createElementNS(revisionGraph.canvas.namespaceURI,"title")).appendChild(document.createTextNode(i.refs)),d.node.appendChild(l)),g.push(d)}),g.toFront()},$(function(){"use strict";window.drawRevisionGraph&&(window.drawRevisionGraph=PurpleMine.RevisionGraph,$(window).resize())}),(PurpleMine=PurpleMine||{}).SidebarToggler=function(){"use strict";var i,e={en:{toggler:"Toggle sidebar"},ro:{toggler:"Deschide/închide bara laterală"},fr:{toggler:"Basculer la barre latérale"},pl:{toggler:"Pokaż/ukryj panel boczny"},ja:{toggler:"サイドバーの切り替え"}};function t(){if(i)return i;(i=this).sidebarVisible=!0,this.sidebarHiding=null,this.$toggler=null,this.$header=$("#header"),this.$main=$("#main"),this.$sidebar=$("#sidebar"),this.lang=document.documentElement.lang,void 0===e[this.lang]&&(this.lang="en"),this._=e[this.lang],window.localStorage&&(i.sidebarVisible=null===localStorage.getItem("PurpleMine:sidebarHidden")),0<i.$sidebar.length&&!1===i.$main.hasClass("nosidebar")&&(function(){var e='<a href="javascript:;" class="sidebar-toggler" title="'+i._.toggler+'"></a>';i.$toggler=$(e),i.$header.append(i.$toggler),i.$toggler.on("click",i.toggleSidebar)}(),function(){var t=document.getElementsByTagName("body")[0];window.onkeydown=function(e){t===e.target&&83===e.keyCode&&!1===e.ctrlKey&&!1===e.altKey&&!1===e.shiftKey&&i.toggleSidebar()}}(),!1===i.sidebarVisible)&&i.hideSidebar(!0)}return t.prototype.toggleSidebar=function(){i.sidebarVisible?i.hideSidebar():i.showSidebar()},t.prototype.hideSidebar=function(e){!0===e?this.$sidebar.addClass("sidebar-hiding sidebar-hidden"):(this.$sidebar.addClass("sidebar-hiding"),this.sidebarHiding=setTimeout(function(){i.$sidebar.addClass("sidebar-hidden")},500)),this.$toggler.addClass("sidebar-hidden"),this.sidebarVisible=!1,window.localStorage&&localStorage.setItem("PurpleMine:sidebarHidden","x")},t.prototype.showSidebar=function(){clearTimeout(this.sidebarHiding),i.$sidebar.removeClass("sidebar-hidden"),setTimeout(function(){i.$sidebar.removeClass("sidebar-hiding")},50),this.$toggler.removeClass("sidebar-hidden"),this.sidebarVisible=!0,window.localStorage&&localStorage.removeItem("PurpleMine:sidebarHidden")},t}(),$(function(){"use strict";new PurpleMine.SidebarToggler,new PurpleMine.HistoryTabs,new PurpleMine.MenuCollapse});
// Точное определение столбца cf_1
$(document).ready(function() {
  
  function hideBracketsInCf1() {
    // Вариант 1: по классу ячейки (стандартный в Redmine)
    $('table.list td.cf_1, table.list td[class*="cf_"]').each(function() {
      processCell($(this));
    });
    
    // Вариант 2: по заголовку столбца (более надежно)
    $('table.list thead th').each(function(index) {
      var $th = $(this);
      var headerText = $th.text().toLowerCase();
      
      // Ищем столбец с cf_1 или другим нужным названием
      if (headerText.indexOf('cf_1') !== -1 || headerText.match(/название.*поля/i)) {
        $('table.list tbody tr').each(function() {
          var $td = $(this).find('td').eq(index);
          if ($td.length) {
            processCell($td);
          }
        });
      }
    });
  }
  
  function processCell($cell) {
    var originalText = $cell.text().trim();
    var regex = /^(.*?)\s*\(([^)]+)\)$/;
    var match = originalText.match(regex);
    
    if (match && !$cell.data('processed')) {
      var visibleText = match[1].trim();
      var hiddenText = match[2];
      
      $cell.data('processed', true);
      $cell.html(
        '<span class="cf-visible">' + visibleText + '</span>' +
        '<span class="cf-hidden" style="display: none; opacity: 0.6; font-size: 0.9em;">' +
        ' (' + hiddenText + ')' +
        '</span>'
      );
      
      // Добавляем подсказку
      $cell.attr('title', 'Полное значение: ' + originalText);
      $cell.css('cursor', 'help');
      
      // Показывать скобки при наведении
      $cell.hover(
        function() {
          $(this).find('.cf-hidden').show();
        },
        function() {
          $(this).find('.cf-hidden').hide();
        }
      );
    }
  }
  
  // Запускаем обработку
  hideBracketsInCf1();
  
  // Обработка AJAX и динамического контента
  $(document).ajaxComplete(function() {
    setTimeout(hideBracketsInCf1, 150);
  });
});